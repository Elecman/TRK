/***************************
 *Выпадающее меню с категориями товаров
 ***************************/
var TopMenu = function (props, callback) {
    if (!(this instanceof TopMenu)) {
        return new TopMenu(props, callback);
    }
    var topMenu = this;

    var p = {
        columnWrapperClass: '.columns',
        columnElementWrapper: 'li',
    };

    p = $.extend(p, props);

    var menuInit = function () {
        if ($(p.columnWrapperClass).length) {
            //console.log('p.columnWrapperClass', p.columnWrapperClass);
            var columnCount = $(p.columnWrapperClass + ' ' + p.columnElementWrapper).length;
            //console.log('columnCount', columnCount);
            if (columnCount <= 15) {
                $(p.columnWrapperClass).addClass("one-col");
            } else if (columnCount > 10 && columnCount <= 20) {
                $(p.columnWrapperClass).addClass("two-col");
            } else if (columnCount > 20) {
                $(p.columnWrapperClass).addClass("three-col");
            }
        }
    };

    var construct = function () {
        //console.log('TopMenu construct fired');
        menuInit();

        if (typeof topMenu[callback] == 'function')
            topMenu[callback]();
    };

    construct();
};

$(document).ready(function () {
    var p = {
        columnWrapperClass: '.columns',
        columnElementWrapper: 'li',
    };
    TopMenu(p);

    $('.footer_show').click(function (e) {
        e.preventDefault();
        $(this).hide()
        $('.fotter_hidden').show();
        return false;
    });
    $('.footer_hide').click(function (e) {
        e.preventDefault();
        $('.footer_show').show()
        $('.fotter_hidden').hide();
        return false;
    });
    // Прокрутка страницы
    $(window).scroll(function () {
        if ($(this).scrollTop() !== 0) {
            $("#toTop").fadeIn();
        }
        else {
            $("#toTop").fadeOut();
        }
    });
    $("#toTop").click(function () {
        $("body,html").animate({scrollTop: 0}, 800);
    });

    $(function () {
        // open/hide mobile menu on click on burger menu
        $(document).on('click', '.navbar-toggle', function () {
            $(this).toggleClass('burger-toggle--opened');
            $('.page-header__nav-area').toggleClass('page-header__nav-area--opened animated fadeInLeft');
        });

    });
    $("#carousel-example-generic").carousel({
        swipe: 60 // percent-per-second, default is 50. Pass false to disable swipe
    });

    /*
         Категория товаров
     */
    //  Слайдер картинок в категории товаров
    if ($(this).find('.row.product-view').length) {
        function caruselInit() {
            $(document).ready(function () {
                var sync1wrapper = $('.slider-big-img');
                sync1wrapper.each(function () {
                    var sync1 = $(this);
                    //console.log(sync1);
                    // TODO: check if className is greater than 0
                    var dataSliderSku = parseInt(sync1.attr('class').match(/\s(?:sku-)(\d*)\s/)[1]);
                    sync1 = $('.slider-big-img.sku-' + dataSliderSku);

                    //console.log(sync1);
                    var sync2 = $('.slider-small-img.sku-' + dataSliderSku);
                    //console.log(sync2);
                    var slidesPerPage = 4; //globaly define number of elements per page
                    var syncedSecondary = true;

                    sync1.owlCarousel({
                        items: 1,
                        slideSpeed: 2000,
                        nav: true,
                        autoplay: false,
                        dots: false,
                        loop: false,
                        responsiveRefreshRate: 200,
                    }).on('changed.owl.carousel', syncPosition);

                    sync2
                        .on('initialized.owl.carousel', function () {
                            $(".owl-item").eq(0).addClass("current");
                        })
                        .owlCarousel({
                            items: slidesPerPage,
                            dots: false,
                            nav: false,
                            smartSpeed: 200,
                            slideSpeed: 350,
                            slideBy: slidesPerPage, //alternatively you can slide by 1, this way the active slide will stick to the first item in the second carousel
                            responsiveRefreshRate: 100,
                        }).on('changed.owl.carousel', syncPosition2);

                    function syncPosition(el) {
                        //if you set loop to false, you have to restore this next line
                        var current = el.item.index;
                        //if you disable loop you have to comment this block
                        //var count = el.item.count - 1;
                        // var current = Math.round(el.item.index - (el.item.count / 2) - .5);
                        // if (current < 0) {
                        //     current = count;
                        // }
                        // if (current > count) {
                        //     current = 0;
                        // }
                        //end block

                        sync2
                            .find(".owl-item")
                            .removeClass("current")
                            .eq(current)
                            .addClass("current");
                        var onscreen = sync2.find('.owl-item.active').length - 1;
                        var start = sync2.find('.owl-item.active').first().index();
                        var end = sync2.find('.owl-item.active').last().index();

                        if (current > end) {
                            sync2.data('owl.carousel').to(current, 100, true);
                        }
                        if (current < start) {
                            sync2.data('owl.carousel').to(current - onscreen, 100, true);
                        }
                    }

                    function syncPosition2(el) {
                        if (syncedSecondary) {
                            var number = el.item.index;
                            sync1.data('owl.carousel').to(number, 100, true);
                        }
                    }

                    sync2.on("click", ".owl-item", function (e) {
                        e.preventDefault();
                        var number = $(this).index();
                        sync1.data('owl.carousel').to(number, 300, true);
                    });
                });
            });
        }
    }
    $(document).ready(function () {
        caruselInit();
        filterMoneyInit();
    });
    //  Появление кнопки купить при наведение на блок
    $('.js-product').hover(function () {
        $(this).find('.old_price').hide();
        $(this).find('.buy-btn').show();
    }, function () {
        $(this).find('.old_price').show();
        $(this).find('.buy-btn').hide();
    });

    //  Прячем фильтр при нажатии на кнопку
    $('.js-show-filter').click(function (e) {
        e.preventDefault();
        $('.js-big-filter').toggle();
        return false;
    });
    //  Инициализация табов в карточке товаров
    $('#myTabs a').click(function (e) {
        e.preventDefault()
        $(this).tab('show')
    })
    /*
    TODO: Настройки фильтра
     */

    if($(this).find('.js-big-filter.price-slider').length){
        function filterMoneyInit(){
            $(document).ready(function () {
                var marginSlider  = document.getElementById('slider-range');
                noUiSlider.create(marginSlider , {
                    start: [0, 125000],
                    margin: 50,
                    step: 50,
                    range: {
                        'min': 0,
                        'max': 125000
                    },
                    direction: 'ltr',
                    connect: true,
                    format: wNumb({
                        decimals: 0,
                    })
                });
                var marginMin = document.getElementById('slider-margin-value-min'),
                    marginMax = document.getElementById('slider-margin-value-max');

                marginSlider.noUiSlider.on('update', function( values, handle ) {
                    Math.ceil(handle);
                    if ( handle ) {
                        marginMax.innerHTML = values[handle];
                    } else {
                        marginMin.innerHTML = values[handle];
                    }
                });
            });
        }
    } else { console.log('ololo')};
    /*
    TODO: Инициализация свайпа меню в мобильной версии
     */
    $(document).ready(function () {
        if (screen.width <= 768) {
            var TouchMenu = TouchMenuLA({
                target: document.getElementById('menu')
            });

            document.getElementById('menu-open').addEventListener('click', function () {
                TouchMenu.toggle();
            });
        } else {
            document.getElementsByClassName('menu').id = 'off';
        }
    });
    /*
    TODO: Прокрутка табов виджита социальных сетей
     */
    $('#social-tab a').hover(function (e) {
        e.preventDefault()
        $(this).tab('show')
    })
    if (screen.width >= 1024) {
        $(".dropdown").hover(
            function () {
                $('.dropdown-menu', this).stop(true, true).fadeIn(400);
                $(this).toggleClass('open');
            },
            function () {
                $('.dropdown-menu', this).stop(true, true).fadeOut(400);
                $(this).toggleClass('open');
            });
    } else {
        $(".dropdown").click(
            function () {
                $('.dropdown-menu', this).toggle();
                $(this).toggleClass('open');
            });
    }


    $(".trigger").on('click',
        function () {
            if (!$(this).parents('.hasdrop').hasClass('active')) {
                var targetHeight = $(this).parents('.hasdrop').find('.drop_content').innerHeight();
                $('.hasdrop.active').removeClass('active').find('.dropdown-click').stop().animate({'height': 0}, 250, function () {
                    $(this).find('.active').removeClass('active');
                });
                $(this).parents('.hasdrop').addClass('active')
                    .find('.dropdown-click').stop().animate({'height': targetHeight}, 250, function () {
                    $(this).height('auto');
                });
            } else {
                $(this).parents('.hasdrop').removeClass('active').find('.dropdown-click').stop().animate({'height': 0}, 250, function () {
                    $(this).find('.active').removeClass('active');
                });
            }
        });
    return false;
})
